import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/audio_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AudioProvider>();

    return Scaffold(
      backgroundColor: const Color(0xFF191414),
      appBar: AppBar(
        backgroundColor: const Color(0xFF191414),
        title: const Text('Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Volume',
                  style: TextStyle(color: Colors.white, fontSize: 16)),
            ),
            Slider(
              value: 1.0,
              min: 0.0,
              max: 1.0,
              onChanged: (v) => provider.setVolume(v),
            ),
            const SizedBox(height: 12),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Speed',
                  style: TextStyle(color: Colors.white, fontSize: 16)),
            ),
            Slider(
              value: 1.0,
              min: 0.5,
              max: 2.0,
              divisions: 6,
              onChanged: (v) => provider.setSpeed(v),
            ),
          ],
        ),
      ),
    );
  }
}
