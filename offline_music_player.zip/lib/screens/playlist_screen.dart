import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/song_model.dart';
import '../providers/playlist_provider.dart';
import '../services/playlist_service.dart';

class PlaylistScreen extends StatefulWidget {
  const PlaylistScreen({super.key});

  @override
  State<PlaylistScreen> createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  final PlaylistService _library = PlaylistService();
  List<AppSong> _allSongs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final songs = await _library.getAllSongs();
    if (!mounted) return;
    setState(() {
      _allSongs = songs;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF191414),
      appBar: AppBar(
        backgroundColor: const Color(0xFF191414),
        title: const Text('Playlists'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _createPlaylistDialog(context),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Consumer<PlaylistProvider>(
              builder: (context, provider, child) {
                final playlists = provider.playlists;

                if (playlists.isEmpty) {
                  return const Center(
                    child: Text('No playlists yet',
                        style: TextStyle(color: Colors.grey)),
                  );
                }

                return ListView.builder(
                  itemCount: playlists.length,
                  itemBuilder: (context, i) {
                    final p = playlists[i];
                    return ListTile(
                      title: Text(p.name,
                          style: const TextStyle(color: Colors.white)),
                      subtitle: Text('${p.songIds.length} songs',
                          style: const TextStyle(color: Colors.grey)),
                      trailing: PopupMenuButton<String>(
                        color: const Color(0xFF282828),
                        onSelected: (v) {
                          if (v == 'rename')
                            _renameDialog(context, p.id, p.name);
                          if (v == 'delete') provider.deletePlaylist(p.id);
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'rename', child: Text('Rename')),
                          PopupMenuItem(value: 'delete', child: Text('Delete')),
                        ],
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PlaylistDetailScreen(
                              playlistId: p.id,
                              playlistName: p.name,
                              allSongs: _allSongs,
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
    );
  }

  Future<void> _createPlaylistDialog(BuildContext context) async {
    final controller = TextEditingController();

    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF282828),
        title: const Text('Create Playlist'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Playlist name'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('Create')),
        ],
      ),
    );

    if (name == null || name.isEmpty) return;

    final id = DateTime.now().millisecondsSinceEpoch.toString();
    await context.read<PlaylistProvider>().createPlaylist(id: id, name: name);
  }

  Future<void> _renameDialog(
      BuildContext context, String id, String current) async {
    final controller = TextEditingController(text: current);

    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF282828),
        title: const Text('Rename Playlist'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'New name'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, controller.text.trim()),
              child: const Text('Save')),
        ],
      ),
    );

    if (name == null || name.isEmpty) return;
    await context.read<PlaylistProvider>().renamePlaylist(id, name);
  }
}

class PlaylistDetailScreen extends StatelessWidget {
  final String playlistId;
  final String playlistName;
  final List<AppSong> allSongs;

  const PlaylistDetailScreen({
    super.key,
    required this.playlistId,
    required this.playlistName,
    required this.allSongs,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF191414),
      appBar: AppBar(
        backgroundColor: const Color(0xFF191414),
        title: Text(playlistName),
        actions: [
          IconButton(
            icon: const Icon(Icons.playlist_add),
            onPressed: () => _addSongSheet(context),
          ),
        ],
      ),
      body: Consumer<PlaylistProvider>(
        builder: (context, provider, child) {
          final playlist =
              provider.playlists.firstWhere((p) => p.id == playlistId);
          final songs =
              allSongs.where((s) => playlist.songIds.contains(s.id)).toList();

          if (songs.isEmpty) {
            return const Center(
              child: Text('No songs in this playlist',
                  style: TextStyle(color: Colors.grey)),
            );
          }

          return ListView.builder(
            itemCount: songs.length,
            itemBuilder: (context, i) {
              final song = songs[i];
              return ListTile(
                title: Text(song.title,
                    style: const TextStyle(color: Colors.white)),
                subtitle: Text(song.artist,
                    style: const TextStyle(color: Colors.grey)),
                trailing: IconButton(
                  icon: const Icon(Icons.remove_circle_outline,
                      color: Colors.white),
                  onPressed: () => provider.removeSong(playlistId, song.id),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _addSongSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF282828),
      builder: (_) {
        return SafeArea(
          child: ListView.builder(
            itemCount: allSongs.length,
            itemBuilder: (context, i) {
              final song = allSongs[i];
              return ListTile(
                title: Text(song.title,
                    style: const TextStyle(color: Colors.white)),
                subtitle: Text(song.artist,
                    style: const TextStyle(color: Colors.grey)),
                onTap: () async {
                  await context
                      .read<PlaylistProvider>()
                      .addSong(playlistId, song.id);
                  if (context.mounted) Navigator.pop(context);
                },
              );
            },
          ),
        );
      },
    );
  }
}
