import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/song_model.dart';
import '../providers/playlist_provider.dart';

class SongTile extends StatelessWidget {
  final AppSong song;
  final List<AppSong> allSongs;
  final VoidCallback onTap;

  const SongTile({
    super.key,
    required this.song,
    required this.allSongs,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: _art(),
      title: Text(
        song.title,
        style:
            const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        song.artist,
        style: const TextStyle(color: Colors.grey),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: IconButton(
        icon: const Icon(Icons.more_vert, color: Colors.grey),
        onPressed: () => _menu(context),
      ),
      onTap: onTap,
    );
  }

  Widget _art() {
    final p = song.albumArt;
    final img = p != null && p.isNotEmpty && File(p).existsSync()
        ? Image.file(File(p), fit: BoxFit.cover)
        : Image.asset('assets/images/default_album_art.png', fit: BoxFit.cover);

    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: SizedBox(width: 50, height: 50, child: img),
    );
  }

  void _menu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF282828),
      builder: (_) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.playlist_add, color: Colors.white),
                title: const Text('Add to playlist',
                    style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  _pickPlaylist(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.info_outline, color: Colors.white),
                title: const Text('Song info',
                    style: TextStyle(color: Colors.white)),
                subtitle: Text(song.filePath,
                    style: const TextStyle(color: Colors.grey), maxLines: 1),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      },
    );
  }

  void _pickPlaylist(BuildContext context) {
    final provider = context.read<PlaylistProvider>();
    final playlists = provider.playlists;

    if (playlists.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Create a playlist first')),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF282828),
      builder: (_) {
        return SafeArea(
          child: ListView.builder(
            itemCount: playlists.length,
            itemBuilder: (context, i) {
              final p = playlists[i];
              return ListTile(
                title:
                    Text(p.name, style: const TextStyle(color: Colors.white)),
                subtitle: Text('${p.songIds.length} songs',
                    style: const TextStyle(color: Colors.grey)),
                onTap: () async {
                  await provider.addSong(p.id, song.id);
                  if (context.mounted) Navigator.pop(context);
                },
              );
            },
          ),
        );
      },
    );
  }
}
