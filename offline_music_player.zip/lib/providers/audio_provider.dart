import 'dart:math';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../models/song_model.dart';
import '../models/playback_state_model.dart';
import '../services/audio_player_service.dart';
import '../services/storage_service.dart';

class AudioProvider extends ChangeNotifier {
  final AudioPlayerService _audioService;
  final StorageService _storageService;

  List<AppSong> _playlist = [];
  int _currentIndex = 0;

  bool _isShuffleEnabled = false;
  LoopMode _loopMode = LoopMode.off;

  final Random _random = Random();

  AudioProvider(this._audioService, this._storageService) {
    _init();
  }

  List<AppSong> get playlist => _playlist;
  int get currentIndex => _currentIndex;
  AppSong? get currentSong =>
      _playlist.isEmpty ? null : _playlist[_currentIndex];
  bool get isShuffleEnabled => _isShuffleEnabled;
  LoopMode get loopMode => _loopMode;

  Stream<Duration> get positionStream => _audioService.positionStream;
  Stream<Duration?> get durationStream => _audioService.durationStream;
  Stream<bool> get playingStream => _audioService.playingStream;
  Stream<PlaybackStateModel> get playbackStateStream =>
      _audioService.playbackStateStream;

  bool get isPlaying => _audioService.isPlaying;

  Future<void> _init() async {
    await _audioService.configureAudioSession();

    _isShuffleEnabled = await _storageService.getShuffleState();

    final repeatMode = await _storageService.getRepeatMode();
    _loopMode = _intToLoopMode(repeatMode);
    await _audioService.setLoopMode(_loopMode);

    final volume = await _storageService.getVolume();
    await _audioService.setVolume(volume);

    notifyListeners();
  }

  Future<void> setPlaylist(List<AppSong> songs, int startIndex) async {
    if (songs.isEmpty) return;

    _playlist = songs;
    _currentIndex = startIndex.clamp(0, songs.length - 1);

    await _playSongAtIndex(_currentIndex);
  }

  Future<void> restoreLastSession(List<AppSong> songs) async {
    final lastId = await _storageService.getLastPlayed();
    if (lastId == null || songs.isEmpty) return;

    final index = songs.indexWhere((s) => s.id == lastId);
    if (index < 0) return;

    _playlist = songs;
    _currentIndex = index;

    await _audioService.loadAudio(_playlist[_currentIndex].filePath);

    final ms = await _storageService.getLastPosition();
    if (ms > 0) {
      await _audioService.seek(Duration(milliseconds: ms));
    }

    notifyListeners();
  }

  Future<void> _playSongAtIndex(int index) async {
    if (_playlist.isEmpty) return;
    if (index < 0 || index >= _playlist.length) return;

    _currentIndex = index;

    final song = _playlist[index];
    await _audioService.loadAudio(song.filePath);
    await _audioService.play();

    await _storageService.saveLastPlayed(song.id);
    await _storageService.saveLastPosition(0);

    notifyListeners();
  }

  Future<void> playPause() async {
    if (_playlist.isEmpty) return;

    if (_audioService.isPlaying) {
      await _storageService
          .saveLastPosition(_audioService.currentPosition.inMilliseconds);
      await _audioService.pause();
    } else {
      await _audioService.play();
    }
    notifyListeners();
  }

  Future<void> next() async {
    if (_playlist.isEmpty) return;

    final nextIndex = _isShuffleEnabled
        ? _getRandomIndex(exclude: _currentIndex)
        : (_currentIndex + 1) % _playlist.length;

    await _playSongAtIndex(nextIndex);
  }

  Future<void> previous() async {
    if (_playlist.isEmpty) return;

    if (_audioService.currentPosition.inSeconds > 3) {
      await _audioService.seek(Duration.zero);
      return;
    }

    final prevIndex = _isShuffleEnabled
        ? _getRandomIndex(exclude: _currentIndex)
        : (_currentIndex - 1 + _playlist.length) % _playlist.length;

    await _playSongAtIndex(prevIndex);
  }

  Future<void> seek(Duration position) => _audioService.seek(position);

  Future<void> toggleShuffle() async {
    _isShuffleEnabled = !_isShuffleEnabled;
    await _storageService.saveShuffleState(_isShuffleEnabled);
    notifyListeners();
  }

  Future<void> toggleRepeat() async {
    if (_loopMode == LoopMode.off) {
      _loopMode = LoopMode.all;
    } else if (_loopMode == LoopMode.all) {
      _loopMode = LoopMode.one;
    } else {
      _loopMode = LoopMode.off;
    }

    await _audioService.setLoopMode(_loopMode);
    await _storageService.saveRepeatMode(_loopModeToInt(_loopMode));
    notifyListeners();
  }

  Future<void> setVolume(double volume) async {
    final v = volume.clamp(0.0, 1.0);
    await _audioService.setVolume(v);
    await _storageService.saveVolume(v);
    notifyListeners();
  }

  Future<void> setSpeed(double speed) async {
    await _audioService.setSpeed(speed.clamp(0.5, 2.0));
    notifyListeners();
  }

  int _getRandomIndex({int? exclude}) {
    if (_playlist.length <= 1) return 0;

    int idx;
    do {
      idx = _random.nextInt(_playlist.length);
    } while (exclude != null && idx == exclude);

    return idx;
  }

  LoopMode _intToLoopMode(int value) {
    switch (value) {
      case 1:
        return LoopMode.all;
      case 2:
        return LoopMode.one;
      case 0:
      default:
        return LoopMode.off;
    }
  }

  int _loopModeToInt(LoopMode mode) {
    switch (mode) {
      case LoopMode.all:
        return 1;
      case LoopMode.one:
        return 2;
      case LoopMode.off:
        return 0;
    }
  }

  @override
  void dispose() {
    _audioService.dispose();
    super.dispose();
  }
}
