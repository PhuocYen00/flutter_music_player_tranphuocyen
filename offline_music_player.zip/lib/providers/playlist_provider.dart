import 'package:flutter/material.dart';
import '../models/playlist_model.dart';
import '../services/storage_service.dart';

class PlaylistProvider extends ChangeNotifier {
  final StorageService _storage;
  List<PlaylistModel> _playlists = [];

  PlaylistProvider(this._storage) {
    _load();
  }

  List<PlaylistModel> get playlists => _playlists;

  Future<void> _load() async {
    _playlists = await _storage.getPlaylists();
    notifyListeners();
  }

  Future<void> _persist() async {
    await _storage.savePlaylists(_playlists);
  }

  Future<void> createPlaylist(
      {required String id, required String name}) async {
    final now = DateTime.now();
    _playlists = [
      PlaylistModel(
        id: id,
        name: name,
        songIds: const [],
        createdAt: now,
        updatedAt: now,
      ),
      ..._playlists
    ];
    await _persist();
    notifyListeners();
  }

  Future<void> renamePlaylist(String playlistId, String newName) async {
    _playlists = _playlists.map((p) {
      if (p.id != playlistId) return p;
      return p.copyWith(name: newName, updatedAt: DateTime.now());
    }).toList();
    await _persist();
    notifyListeners();
  }

  Future<void> deletePlaylist(String playlistId) async {
    _playlists = _playlists.where((p) => p.id != playlistId).toList();
    await _persist();
    notifyListeners();
  }

  Future<void> addSong(String playlistId, String songId) async {
    _playlists = _playlists.map((p) {
      if (p.id != playlistId) return p;
      if (p.songIds.contains(songId)) return p;
      return p
          .copyWith(songIds: [...p.songIds, songId], updatedAt: DateTime.now());
    }).toList();
    await _persist();
    notifyListeners();
  }

  Future<void> removeSong(String playlistId, String songId) async {
    _playlists = _playlists.map((p) {
      if (p.id != playlistId) return p;
      return p.copyWith(
        songIds: p.songIds.where((id) => id != songId).toList(),
        updatedAt: DateTime.now(),
      );
    }).toList();
    await _persist();
    notifyListeners();
  }
}
